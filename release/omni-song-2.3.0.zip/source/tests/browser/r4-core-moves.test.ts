/**
 * Song moves played on the real engine (arrange-no-change-over-time,
 * capability-09 stage 1): a section's Fade in / Fade out move the song gain and
 * Filter rise moves the parts' Tone across the section, rendered offline as an
 * export renders them, and live through the real-time transport the same way.
 * A sine test instrument holds one tone per bar, so levels are easy to read.
 */
import { describe, expect, it } from 'vitest';
import { AudioEngine } from '../../src/audio/engine';
import type { MeterFrame } from '../../src/audio/contracts';
import type { Project, SongMove } from '../../src/project/types';
import { renderOffline } from '../../src/render/offline';
import { Sequencer } from '../../src/time/sequencer';
import { RealtimeTransport } from '../../src/time/transport';
import { LATENCY, SR, baseProject, coreProject, makeFactory, pitchForHz, toneAmp } from './engine-harness';
import { makeClip } from '../unit/sequencer-fixtures';

const HZ = 1000;
const TONE = Math.round(pitchForHz(HZ) * 1000) / 1000;
const VEL = 0.25;
/** 120 BPM: a beat is 0.5 s, a bar 2 s. */
const BEAT_S = 0.5;

/**
 * t3 holds a tone through every bar of every row. Song: sections and regions A (row 0, 1 bar), B (row 1,
 * 2 bars), C (row 2, 1 bar).
 */
function song(p: Project, moves: { A?: SongMove[]; B?: SongMove[] }, pitch = TONE): Project {
  for (const t of p.tracks) t.clips = t.clips.map(() => null);
  const t3 = p.tracks.find((t) => t.id === 't3')!;
  for (let row = 0; row < 3; row++) t3.clips[row] = makeClip(1, [[0, pitch, 384, VEL]], `tone${row}`);
  const at = { A: [0, 1], B: [1, 2], C: [3, 1] } as const;
  const names = ['A', 'B', 'C'] as const;
  p.arrangement = {
    tailSeconds: 0,
    regions: names.map((id, row) => ({ id, trackId: 't3', clipId: t3.clips[row]!.id, start: at[id][0], bars: at[id][1], offset: 0 })),
    sections: names.map((id) => ({ id, name: id, start: at[id][0], bars: at[id][1], ...(id !== 'C' && moves[id] ? { moves: moves[id] } : {}) })),
  };
  return p;
}

async function render(p: Project): Promise<Float32Array> {
  const { factory } = makeFactory();
  const buf = await renderOffline({
    project: p,
    source: { kind: 'song' },
    sampleRate: SR,
    tailSeconds: 0,
    align: true,
    createEngine: (ctx) => AudioEngine.create(ctx, { samples: { get: () => null }, seed: 7, meters: false, instrumentFactory: factory }),
  });
  return buf.getChannelData(0);
}

/** Tone level (linear, re. the note's own level) over a beat starting at song time `t` (an aligned export: no offset). */
function beatLevel(d: Float32Array, t: number, hz = HZ): number {
  return toneAmp(d, hz, t + 0.03, t + BEAT_S - 0.03) / VEL;
}

const db = (x: number) => 20 * Math.log10(x);

describe('song moves, rendered (an export)', () => {
  it('Fade in: the first beat of the section is at least 20 dB below its last; the section before is untouched, the one after at unity', async () => {
    const d = await render(song(coreProject(), { B: [{ id: 'f', kind: 'fadeIn' }] }));
    const a = beatLevel(d, 1.0);
    const first = beatLevel(d, 2.0);
    const last = beatLevel(d, 5.5);
    const after = beatLevel(d, 6.5);
    console.info(`[moves] fade in: A ${db(a).toFixed(1)} dB, B first beat ${db(first).toFixed(1)} dB, last ${db(last).toFixed(1)} dB, C ${db(after).toFixed(1)} dB`);
    expect(db(last) - db(first)).toBeGreaterThanOrEqual(20);
    expect(a).toBeGreaterThan(0.9);
    expect(after).toBeGreaterThan(0.9);
    expect(last).toBeGreaterThan(0.8);
  });

  it('Fade out: falls to silence across the section, then the next section is back at unity', async () => {
    const d = await render(song(coreProject(), { B: [{ id: 'f', kind: 'fadeOut' }] }));
    // Linear in gain: 3/4 a quarter in, 1/4 three quarters in.
    expect(beatLevel(d, 2.75)).toBeCloseTo(0.75, 1);
    expect(beatLevel(d, 4.75)).toBeCloseTo(0.25, 1);
    expect(db(beatLevel(d, 5.5))).toBeLessThan(-20);
    expect(beatLevel(d, 6.5)).toBeGreaterThan(0.9);
  });

  it('Filter rise: the part’s Tone starts closed and opens across the section, back at its own value after it', async () => {
    // A bright tone (6 kHz) through the part's filter, whose cutoff the Tone big knob sets.
    const hz = 6000;
    const p = song(baseProject(), { B: [{ id: 'r', kind: 'filterRise', parts: ['t3'] }] }, Math.round(pitchForHz(hz) * 1000) / 1000);
    const d = await render(p);
    const own = beatLevel(d, 1.0, hz);
    const start = beatLevel(d, 2.0, hz);
    const end = beatLevel(d, 5.5, hz);
    const after = beatLevel(d, 6.5, hz);
    console.info(`[moves] filter rise: A ${db(own).toFixed(1)} dB, B first beat ${db(start).toFixed(1)} dB, last ${db(end).toFixed(1)} dB, C ${db(after).toFixed(1)} dB`);
    expect(db(own) - db(start)).toBeGreaterThan(6);
    expect(Math.abs(db(end) - db(own))).toBeLessThan(1.5);
    expect(Math.abs(db(after) - db(own))).toBeLessThan(0.5);
  });
});

describe('song moves, live (the real-time transport on an AudioContext)', () => {
  /** Plays `p` as a song live (from `fromTick`) and reads the master level whenever the audio clock reaches song time t. */
  async function liveLevels(p: Project, times: number[], fromTick = 0): Promise<number[]> {
    const ctx = new AudioContext({ sampleRate: SR });
    await ctx.resume();
    const { factory } = makeFactory();
    const engine = await AudioEngine.create(ctx, { samples: { get: () => null }, seed: 7, meters: true, instrumentFactory: factory });
    engine.setProject(p);
    const seq = new Sequencer({ getProject: () => p });
    const transport = new RealtimeTransport({ ctx, engine, sequencer: seq });
    const f: MeterFrame = { masterPeakL: 0, masterPeakR: 0, masterRms: 0, limiterReductionDb: 0, tracks: [] };
    try {
      transport.start({ mode: { kind: 'song', fromBar: fromTick / 384 } });
      const t0 = seq.timeAt(fromTick);
      const out: number[] = [];
      for (const t of times) {
        const when = t0 + (t - (fromTick / 384) * 2) + LATENCY;
        while (ctx.currentTime < when) await new Promise((r) => setTimeout(r, 5));
        engine.readMeters(f);
        // A sine of amplitude VEL has RMS VEL/√2.
        out.push(f.masterRms / (VEL * Math.SQRT1_2));
      }
      return out;
    } finally {
      transport.dispose();
      engine.dispose();
      await ctx.close();
    }
  }

  it('a song with a fade-out section: live levels follow the offline render within the meter tolerance', async () => {
    const p = song(coreProject(), { B: [{ id: 'f', kind: 'fadeOut' }] });
    const times = [1.25, 2.75, 3.75, 4.75];
    const d = await render(p);
    const offline = times.map((t) => toneAmp(d, HZ, t - 0.02, t + 0.02) / VEL);
    const live = await liveLevels(p, times);
    console.info(`[moves] fade out, offline ${offline.map((x) => x.toFixed(3)).join(' ')}, live ${live.map((x) => x.toFixed(3)).join(' ')}`);
    for (let i = 0; i < times.length; i++) {
      expect(live[i], `at ${times[i]} s`).toBeGreaterThan(offline[i] - 0.06);
      expect(live[i], `at ${times[i]} s`).toBeLessThan(offline[i] + 0.06);
    }
  });

  it('a song that opens with a Fade in starts from silence, also again after Stop; Pause and Play in the fade go on from the level reached', async () => {
    const p = song(coreProject(), { A: [{ id: 'f', kind: 'fadeIn' }] });
    const ctx = new AudioContext({ sampleRate: SR });
    await ctx.resume();
    const { factory } = makeFactory();
    const engine = await AudioEngine.create(ctx, { samples: { get: () => null }, seed: 7, meters: true, instrumentFactory: factory });
    engine.setProject(p);
    const seq = new Sequencer({ getProject: () => p });
    const transport = new RealtimeTransport({ ctx, engine, sequencer: seq });
    const f: MeterFrame = { masterPeakL: 0, masterPeakR: 0, masterRms: 0, limiterReductionDb: 0, tracks: [] };
    /** The level when the audio clock reaches song time `t` of a playback whose tick 0 is at `t0` (relative to the tone's own). */
    const levelAt = async (t0: number, t: number) => {
      while (ctx.currentTime < t0 + t + LATENCY) await new Promise((r) => setTimeout(r, 5));
      engine.readMeters(f);
      return f.masterRms / (VEL * Math.SQRT1_2);
    };
    try {
      const levels: number[] = [];
      for (let pass = 0; pass < 2; pass++) {
        transport.start({ mode: { kind: 'song', fromBar: 0 } });
        const t0 = seq.timeAt(0);
        levels.push(await levelAt(t0, 0.15), await levelAt(t0, 1.75));
        // Stopped at ~90 %: the gain holds there until the next start.
        transport.stop();
      }
      // Pause at about half way (song time 1.0 s), Play again half a second later.
      transport.start({ mode: { kind: 'song', fromBar: 0 } });
      const t0 = seq.timeAt(0);
      await levelAt(t0, 1.0);
      expect(transport.pause()).toBe(true);
      const pausedTick = seq.tickAt(ctx.currentTime);
      await new Promise((r) => setTimeout(r, 500));
      expect(transport.resume()).toBe(true);
      const t1 = seq.timeAt(pausedTick);
      const resumed = await levelAt(t1, 0.1);
      const reached = pausedTick / 384;
      console.info(`[moves] fade-in start ${levels.map((x) => x.toFixed(3)).join(' ')}; resumed at ${reached.toFixed(2)} of the fade: ${resumed.toFixed(3)}`);
      expect(levels[0]).toBeLessThan(0.15);
      expect(levels[1]).toBeGreaterThan(0.75);
      expect(levels[2]).toBeLessThan(0.15);
      expect(levels[3]).toBeGreaterThan(0.75);
      expect(resumed).toBeGreaterThan(reached - 0.1);
      expect(resumed).toBeLessThan(reached + 0.15);
    } finally {
      transport.dispose();
      engine.dispose();
      await ctx.close();
    }
  });

  it('Pause inside a Fade out: a key played while paused is heard at full level; after Play the fade goes on where it was', async () => {
    const p = song(coreProject(), { B: [{ id: 'f', kind: 'fadeOut' }] });
    const ctx = new AudioContext({ sampleRate: SR });
    await ctx.resume();
    const { factory } = makeFactory();
    const engine = await AudioEngine.create(ctx, { samples: { get: () => null }, seed: 7, meters: true, instrumentFactory: factory });
    engine.setProject(p);
    const seq = new Sequencer({ getProject: () => p });
    const transport = new RealtimeTransport({ ctx, engine, sequencer: seq });
    const f: MeterFrame = { masterPeakL: 0, masterPeakR: 0, masterRms: 0, limiterReductionDb: 0, tracks: [] };
    const level = () => {
      engine.readMeters(f);
      return f.masterRms / (VEL * Math.SQRT1_2);
    };
    const wait = async (time: number) => {
      while (ctx.currentTime < time) await new Promise((r) => setTimeout(r, 5));
    };
    try {
      transport.start({ mode: { kind: 'song', fromBar: 0 } });
      // B fades out over song time 2..6 s: pause about a fifth of the way in.
      await wait(seq.timeAt(0) + 2.9);
      expect(transport.pause()).toBe(true);
      const pausedTick = seq.getPosition(ctx.currentTime).tick;
      expect(pausedTick).toBeGreaterThan(384);
      expect(pausedTick).toBeLessThan(768);
      await wait(ctx.currentTime + 0.4);
      // A key while paused (what the session does on every live note: restoreSongGain first).
      transport.restoreSongGain();
      engine.liveNoteOn('t3', TONE, VEL, 'k');
      await wait(ctx.currentTime + 0.25 + LATENCY);
      const key = level();
      engine.liveNoteOff('t3', 'k');
      await wait(ctx.currentTime + 0.4);
      expect(transport.resume()).toBe(true);
      // The tone held at the pause does not start again; the next one (B's second bar, tick 768) sounds
      // where the fade is by then, not at the unity the key brought back.
      const tick = 768 + 30;
      await wait(seq.timeAt(tick) + LATENCY);
      const resumed = level();
      const fade = 1 - (tick / 384 - 1) / 2;
      console.info(`[moves] key while paused ${key.toFixed(3)}; after Play at tick ${tick}: ${resumed.toFixed(3)} (the fade: ${fade.toFixed(3)})`);
      expect(key).toBeGreaterThan(0.9);
      expect(resumed).toBeGreaterThan(fade - 0.08);
      expect(resumed).toBeLessThan(fade + 0.08);
    } finally {
      transport.dispose();
      engine.dispose();
      await ctx.close();
    }
  });

  it('started in the middle of a fade (a seek), it begins at the value the fade has there', async () => {
    const p = song(coreProject(), { B: [{ id: 'f', kind: 'fadeIn' }] });
    // Bar 2 of the song = half way through B's fade in (B spans song bars 1..3).
    const [level] = await liveLevels(p, [4.25], 2 * 384);
    console.info(`[moves] seek into a fade in: ${level.toFixed(3)} (expected ~0.53)`);
    expect(level).toBeGreaterThan(0.45);
    expect(level).toBeLessThan(0.62);
  });
});
