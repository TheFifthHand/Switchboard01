import 'fake-indexeddb/auto';
