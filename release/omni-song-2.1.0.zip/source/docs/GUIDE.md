# Omni Song — a short guide

Start Omni Song first (Windows: double-click **Start Omni Song.bat** in the release zip; see
`START HERE.txt`). It opens in your browser at `http://127.0.0.1:4173/`. Use headphones or speakers
at a moderate volume.

Words used here: a **part** is one instrument (Drums, Bass, Chords …), shown as a column of pads.
A **clip** is a short loop on one pad. A **scene** is a row of clips, launched together.

## Make your first loop (about three minutes)

1. **Jump In.** Press **Jump In**. A House groove starts, and the lit pads say **Playing**. A short
   quick guide points at Play / Pause, the pads and the sound controls; then small **Try this**
   hints suggest one next step at a time. Neither blocks anything: you can skip the guide and hide
   the hints.
2. **Swap a clip.** Tap another pad in the **Bass** column, for example *Rolling*. It shows
   **Next bar** and takes over on the next bar line, in time. Only one clip per part plays at a time.
   The scene buttons on the right (Intro, Groove, Lift, Break) switch every part at once.
3. **Mute and Solo.** Press **Mute** at the top of the **Drums** column: the column dims and says
   **Muted**, and the drums go silent (they keep their place in time). Press it again to bring them
   back. **Solo** plays one part on its own (the others say *Not soloed*); press it again to hear
   everything. The **M** key mutes the selected part.
4. **Change the instrument.** Tap a part's name at the top of its column to select it. On the right,
   press **Change instrument**: sounds are sorted into Drums & Percussion, Bass, Keys, Pads &
   Strings, Leads, Plucks & Bells, Textures & FX and Recordings, with a search box and **Preview**.
   Pick one, and the part plays it right away. **Undo** (Ctrl+Z) brings the old one back.
   Then turn the **big knobs** under it: **Tone** (darker ↔ brighter), **Space** (room around the
   sound), **Echo**, **Motion**, **Drive** and **Pump** (ducks in time with the beat). Drag a knob up
   or down (Shift for fine steps), or focus it and use the arrow keys; double-click resets it.
5. **Drag a clip.** Drag a clip pad onto another pad to **move** it (onto a pad that has a clip, the
   two swap). Hold **Ctrl** (or Alt) while you drop to **copy** it instead. Esc cancels a drag, and
   one Undo puts it back. Drum clips go to drum parts and note clips to melodic parts; the app says
   so if a drop does not fit. Without a mouse: select the pad, choose **Move…**, then the arrow keys
   and Enter.
6. **Pause.** Press **Pause** (or the Space bar). Everything holds exactly where it is; **Play**
   continues from there, in time. **Stop** (Shift+Space) goes back to the start instead.

More to try:

- **Play along** on the little keyboard at the bottom, or with your computer keys (A S D F … for
  white keys, W E T Y … for black keys). **Musical Assist** is on, so you stay in the song's key.
- **Variation** (under the big knobs) makes a new take on the selected part's pattern; **Lock** keeps
  a part exactly as it is.
- **Simple · Advanced** (top right) shows every control: the key and scale, the arpeggiator, swing,
  pan, every effect setting and the cable panel. Your music does not change when you switch.
- **Shape** (top left) shows the selected part in detail: the six knobs, its instrument and its
  effects as cards with one main knob each. **Add effect** offers effects by purpose (Tone,
  Dynamics, Space, Movement, Colour, Stereo).

Your work saves automatically in this browser; the top right shows **Saved**.

## Build a song (about three minutes)

Open **Arrange** (top left). The **Song** lane plays scenes one after another, left to right. Each
**block** is one scene played a number of times; the wider the block, the longer it plays. Under
each block's name is one row per part: a filled bar means that part plays there, **Off** (grey, with
a thin coral edge) means it is switched off in that block, and **Lift: Hook** (striped, with a
layers icon) means it plays another scene's clip there. In Arrange the **Play** button at the top
(or Space) plays the song; ▶ on a block, or a click on the bar numbers, starts it from there. The
block playing now is outlined in amber and says **Playing**, and the lane scrolls along with it
(it waits while your pointer moves over the lane; turn **Follow** off, under the lane, to keep it
still). You can change the song while it plays: every edit is heard right away.

1. **Move a block.** Drag a block by its name (or anywhere on it) left or right with the mouse or a
   pen. On a touch screen, rest your finger on the block for a moment: it pops up, then drag it. A
   quick swipe just scrolls the lane, and holding a block then letting go without moving shows its
   actions. The other blocks slide aside to show where it will land; let go and it clicks into
   place. Hold **Ctrl** (Alt, or ⌘ on a Mac) while dragging to drop a **copy** instead. Esc, or
   letting go away from the lane, puts everything back.
2. **Play it more times, or fewer.** Every block has a small grip at its right edge: drag it. The
   block grows or shrinks one repeat at a time, its header shows the new length, and a bubble says
   how many times it plays ("3 times · 12 bars"). The blocks after it follow; drag past the end of
   the lane and it scrolls on for you. With the keyboard, + and − do the same. The blocks keep their
   size while you edit (a longer song scrolls); **Fit song**, **−** and **+** under the lane, or
   Ctrl+wheel over it, change the zoom. Fit song shows a long song whole (its blocks then show just
   their names: point at one for the rest).
3. **Split and join.** Point at a block: a pair of scissors appears under each line between its
   repeats; click one to cut the block there. Two neighbours that play the same thing show **Join**
   under their seam.
4. **Switch a part in one block.** Click a part's bar in a block to switch it off there (it says
   **Off**, and a message says "Drums off in Groove" with **Undo**); click again to bring it back.
   The rest of the song is not affected.
5. **Combine scenes.** Drag a scene card from **SCENES** onto the middle of a block: the parts that
   are silent in that block take the card's clips (they read *Lift: Hook* before you let go). Hold
   **Shift** while you let go to replace the block's parts with the card's instead. Drop the card
   between two blocks (a line, then a gap, opens there) to add it as a new block; **+** on a card
   adds it at the end.
6. **Select several.** Click a block to select it (teal), Shift+click for a range, Ctrl+click to add
   or remove one. Dragging, **Ctrl+D** (duplicate), **Ctrl+C** / **Ctrl+X** / **Ctrl+V** (copy, cut,
   paste after the selected block) and **Delete** work on all selected blocks at once. Cut a block
   and paste it straight away, and it goes back where it was.
7. **Loop a part of the song.** **Loop** in the Song header says what it will loop: the blocks you
   selected, else the block playing now, else the first block ("Loop Groove (block 2)"). Press it
   and those blocks repeat while the song plays. Select other blocks and press it again to move the
   loop there; press it with the looped blocks (or nothing) selected to play the song through again.
   Or drag across the bar numbers above the blocks: a teal **Loop** band covers the blocks you drag
   over. Drag either end of the band to another block edge to change it. **Play** starts at the
   loop. A click on the bar numbers still plays from that bar.
8. **Shape a block in one step.** Open a block's **⋯** and choose **Shape this block…**:
   - **Build up**: the parts come in one at a time, each time the block plays: pads and textures
     first, then chords, lead and vocal, then percussion and bass, and the drums last.
   - **Strip down**: the other way round: everything first, then the parts drop out (drums first).
   - **Breakdown**: the drums, percussion and bass switch off in that block.

   Build up and Strip down split the block into its repeats; you see the result at once in the part
   cells (**Off** where a part waits) and hear it right away. Each is one Undo, and the song keeps
   its length (a block whose clips have different lengths, say 3 and 4 bars, cannot be shaped: the
   menu says why).

Everything is one Undo away (Ctrl+Z); each edit's message has an **Undo** button too. Each block's
**⋯** button (or right-click, or Enter on a focused block) lists every action: the ones you use most
first (play from here, rename, duplicate, split, join, one more time / one time fewer), then
**Parts…**, **Scenes and clips…**, **Shape this block…**, **Loop…** and **Copy, cut, move…**, which
open in place (**Back** returns), and remove. The **Echo tail** beside the song's length is how many
seconds an exported song keeps ringing after its last block. While you record a performance the
song is locked; the lane says so until you stop.

Without a mouse: Tab to the lane, then ←/→ choose a block (Shift extends the selection), Alt+←/→
moves it, + and − change how many times it plays, ↓ enters its parts (Enter switches one, "."
chooses what it plays), F2 renames, Enter opens the actions. After Undo or Redo the lane keeps your
place.

## Record and export (about three minutes)

**Record a performance**

1. With music playing, press **Performance** in the RECORD group at the top. It turns coral and the
   caption reads *Recording performance*.
2. Play: tap pads, launch scenes, play keys, turn knobs. Cables and instrument choices are locked
   while you record, so the take replays exactly as you played it. (Pause is not available during a
   take; Stop ends it.)
3. Press **Performance** again to stop. The take (*Take 1*) appears in **Arrange → Performances**,
   where you can replay it, rename it, end it earlier, change recorded values or delete actions.

**Record notes into a clip** (optional)

Select a part and a clip, press **Notes**, and play the keyboard or drum pads. The caption shows the
timing grid it snaps to. Grid, metronome and count-in are in the recording options (the metronome
button next to **Performance**). Press **Notes** again to stop; one Undo removes the whole pass.

**Mix and master**

1. Open **Mix** (top left). Each part has a fader with its level meter, **Mute**, **Solo** and
   **Pan**; the master strip has the master fader and **Mute All**.
2. Under **Mastering**, try a preset: **Clean** (nothing), **Gentle**, **Warm**, **Punchy**,
   **Bright**, **Wide**, **Loud** or **Lo-fi**. Each says in one line what it does.
3. Choose a **loudness target**: **Streaming −14 LUFS** suits most music (streaming services play
   songs at about that level), **Gentle −18** leaves more dynamics, **Loud −9** is club level.
4. Play the song for a while: the readings show how loud it is right now (Momentary, Short-term),
   on average (Integrated) and its highest peak (True peak). **Match target** moves the Loudness
   control by the difference. The output limiter always keeps peaks below −1 dBFS.
5. **Compare A/B** lets you hear the mix without mastering, to check it really sounds better.

**Export a WAV**

1. Press **Export** (the dark download button at the top right; on narrow windows it is in the
   **⋯** menu).
2. In **What to export**, choose the clips playing now, a scene, the **Song (arrangement)** or a
   **Performance**.
3. Set **Tail** (seconds for echoes to ring out), **Sample rate**, **Bit depth** and the file name,
   then press **Export WAV**. A progress bar shows the render; **Cancel export** stops it. The file
   is a stereo WAV rendered by the same engine you hear, mastering included, not a recording of
   your speakers.

**Keep a portable copy**

Open the projects button (folder icon with the project's name, top right) → **Export this
project**. The `.omnisong.zip` file holds all musical state and your recordings. **Import project
file…** opens it again in any browser, and also opens `.sb01.zip` files saved by SWITCHBOARD / 01.
Browser storage is working storage; project files are your backup.

## Plug in a MIDI keyboard

*New in 2.0.* Works in Chrome and Edge, which support Web MIDI. Details and options are in the
**MIDI & audio** dialog.

1. Plug in the keyboard or controller (USB, or a MIDI interface).
2. Open **More** (the ⋯ button, top right) → **MIDI & audio…**, and connect MIDI. The browser asks
   for permission the first time.
3. Play. Notes go to the **selected part** (or a part you choose for each input), through Musical
   Assist, and **Notes** and **Performance** record them just like the computer keyboard. Drum parts
   follow the usual General MIDI drum layout.
4. In the same dialog you can **learn** a knob, fader or wheel to one of the big knobs, a part's
   volume, the master volume or the tempo: choose what to control, then move the control.

Once something is connected, a **MIDI & audio** key shows at the top, with a light that flashes when
notes arrive. Unplugging a keyboard never leaves notes hanging.

## Record your voice or guitar

*New in 2.0.* Your browser asks for permission to use the microphone or audio input; the sound
stays on your computer. Details and options are in the **MIDI & audio** dialog.

1. Connect a microphone or an audio interface with your guitar. In **MIDI & audio**, choose the
   input and check the level meter while you play or sing. Monitoring (hearing yourself through
   Omni Song) is off by default, because speakers next to a microphone can howl; use headphones if
   you turn it on.
2. Select a sampler part — the **Vocal** part in every starter — and open **Shape** (press **Show
   every setting** if you do not see its recording editor). The editor has **Record audio**:
   choose 1, 2 or 4 bars and, if you like, a one-bar count-in.
3. Press **Record audio**. Recording starts on the next downbeat, in time with the music, and stops
   by itself after the bars you chose. The take becomes that part's recording, with a clip that
   plays it; one Undo removes it.
4. **Edit recording** works on the part of the take that plays: **Normalize**, **Reverse**,
   **Crop**, **Fade in**, **Fade out** and **Gain**, each one undoable. If takes land a little late
   or early on your setup, the **Recording offset** in MIDI & audio corrects it.
