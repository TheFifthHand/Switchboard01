/**
 * Runtime state: what the audio side is doing right now (transport, launcher,
 * recording, audio device status). Not part of the Project and never saved.
 * Updated at musical-event rate (launches, start/stop), never per frame —
 * playheads and meters read the transport/engine directly in rAF loops.
 *
 * Also the offline readiness of the installed app (fed by pwa.ts), kept here
 * so views can show it without loading the service-worker module.
 */
import { createStore, useStore, shallowEqual } from '../state/store';
import type { Id } from '../project/types';
import type { SongLoop } from '../time/contracts';

export type AudioStatus = 'off' | 'starting' | 'running' | 'suspended' | 'error';

export interface TrackRuntime {
  /** Slot currently sounding, or null. */
  playingSlot: number | null;
  /** Pending change at the next bar: a slot, or null meaning "stop". */
  queued: { slot: number | null; atTick: number } | null;
}

export type PlayMode = 'live' | 'song' | 'replay';
export type RecordingState = 'off' | 'notes' | 'performance';

export interface RuntimeState {
  audio: AudioStatus;
  audioMessage: string | null;
  playing: boolean;
  /**
   * Holding at a pause (`playing` is false): the position, the mode (live pads,
   * song or replay) and every playing clip's phase are kept for Play.
   */
  paused: boolean;
  mode: PlayMode;
  replayId: Id | null;
  /**
   * The song's cursor: the bar (0-based) where Play starts in the Song view,
   * GarageBand's playhead while stopped. Clicking the ruler sets it; Stop
   * after song playback puts it back where that playback started. Where the
   * song plays (or is paused) now is read from the transport per frame
   * (songPlayheadBar in songPlayback.ts), never from here.
   */
  songCursor: number;
  /** The looped bars of the song (Song view), or null: the song plays through. */
  songLoop: SongLoop | null;
  /** The song is playing (or paused) inside the loop and will repeat it; false while it plays towards it or on to the end. */
  songLooping: boolean;
  tracks: Record<Id, TrackRuntime>;
  recording: RecordingState;
  /** Clip that Record Notes writes into. */
  recordTarget: { trackId: Id; slot: number } | null;
  /** Waiting for the count-in bar before recording starts. */
  countingIn: boolean;
  /** Transport stopped itself because scheduling could not keep up (background tab, device). */
  stalled: string | null;
  muteAll: boolean;
  /** The open project is the Jump In starter shown as a preview: not stored until it is changed. */
  preview: boolean;
  /** Notes currently held per track (keyboard/pad highlighting). */
  held: Record<Id, readonly number[]>;
  /** One-line status message shown as a toast (e.g. "Variation: 5 notes changed" [Undo]). */
  notice: Notice | null;
  /**
   * A suggestion with a button of its own ("Add Bass 2 to the song where
   * Groove plays?" [Add]), shown as a toast beside the notices (it does not
   * replace them). Null (or absent): none.
   */
  offer?: Offer | null;
  /**
   * Record Notes is waiting for its clip to start (the next bar, or the end
   * of the count-in): the transport tick recording starts at, so the
   * transport can count the beats down; null (or absent) when not waiting.
   */
  recordStartsAtTick?: number | null;
  /**
   * Record Notes in the song: false while the part being recorded has no
   * region under the playhead (nothing records there). True (or absent)
   * otherwise.
   */
  recordTargetAudible?: boolean;
  /**
   * Recording into the song (the Song view's Record): the part, the song bar
   * the take starts at and the bars it has reached so far (it grows bar by bar
   * on the audio clock; the Song view draws it as a live "Recording…"
   * region). Null (or absent) otherwise. The project is written when the take
   * ends.
   */
  songRecording?: { trackId: Id; startBar: number; bars: number } | null;
  /** The project the last starter (Jump In, a new project) replaced on screen; it stays in My projects. Null (or absent): none. */
  starterReplaced?: { id: Id; name: string } | null;
}

/** What a notice's button does: Undo (or Redo) the history step the message is about. */
export type NoticeAction = 'undo' | 'redo';

export interface Notice {
  id: number;
  text: string;
  tone: 'info' | 'warn' | 'error';
  action?: NoticeAction;
  /**
   * The history step the action applies to (ProjectStore entry id): Undo acts
   * only while it is the newest step (Redo: while it is next to redo), and the
   * toast goes away once it is not. Unset: not known when the notice was made.
   */
  entry?: number;
}

/** See RuntimeState.offer: the words, the button's label and what it does. */
export interface Offer {
  id: number;
  text: string;
  label: string;
  run(): void;
}

export const EMPTY_TRACK_RUNTIME: TrackRuntime = { playingSlot: null, queued: null };

export const runtimeStore = createStore<RuntimeState>({
  audio: 'off',
  audioMessage: null,
  playing: false,
  paused: false,
  mode: 'live',
  replayId: null,
  songCursor: 0,
  songLoop: null,
  songLooping: false,
  tracks: {},
  recording: 'off',
  recordTarget: null,
  countingIn: false,
  stalled: null,
  muteAll: false,
  preview: false,
  held: {},
  notice: null,
  offer: null,
  recordStartsAtTick: null,
  recordTargetAudible: true,
  starterReplaced: null,
  songRecording: null,
});

export function patchRuntime(partial: Partial<RuntimeState>): void {
  runtimeStore.setState((s) => ({ ...s, ...partial }));
}

export function setTrackRuntime(trackId: Id, tr: TrackRuntime): void {
  runtimeStore.setState((s) => {
    const cur = s.tracks[trackId];
    if (cur && cur.playingSlot === tr.playingSlot && shallowEqual(cur.queued, tr.queued)) return s;
    return { ...s, tracks: { ...s.tracks, [trackId]: tr } };
  });
}

let noticeCounter = 0;

/** Where notify() finds the step an Undo / Redo notice is about (the app's project store; see setNoticeHistory). */
let historyTop: ((action: NoticeAction) => number | null) | null = null;

/**
 * Tell notify() how to find the newest undo step and the next redo step (ids),
 * so each Undo notice is tied to the edit that was just made.
 */
export function setNoticeHistory(top: ((action: NoticeAction) => number | null) | null): void {
  historyTop = top;
}

/**
 * Show a message. With an action, the toast offers Undo (or Redo) of the
 * history step it is about: `entry`, or by default the step that is newest
 * right now (call it just after the edit).
 */
export function notify(text: string, tone: 'info' | 'warn' | 'error' = 'info', action?: NoticeAction, entry?: number | null): void {
  noticeCounter += 1;
  // undefined: not known (no history source); null: nothing to undo (redo).
  const step = !action ? undefined : entry !== undefined ? entry : historyTop ? historyTop(action) : undefined;
  // Nothing to undo (or redo): no button.
  const tied = action && step !== null ? { action, ...(step !== undefined ? { entry: step } : {}) } : {};
  patchRuntime({ notice: { id: noticeCounter, text, tone, ...tied } });
}

let offerCounter = 0;

/** Show a suggestion with its own button (see RuntimeState.offer); a newer one replaces it. */
export function offer(text: string, label: string, run: () => void): void {
  offerCounter += 1;
  patchRuntime({ offer: { id: offerCounter, text, label, run } });
}

/** Take the suggestion showing now away (its subject is gone). */
export function withdrawOffer(): void {
  if (runtimeStore.getState().offer) patchRuntime({ offer: null });
}

/** The transport's state in one word, as the transport shows it. */
export type TransportWord = 'Playing' | 'Paused' | 'Stopped' | 'Song' | 'Replay';

export function transportWord(s: Pick<RuntimeState, 'playing' | 'paused' | 'mode'>): TransportWord {
  if (s.paused) return 'Paused';
  if (!s.playing) return 'Stopped';
  return s.mode === 'song' ? 'Song' : s.mode === 'replay' ? 'Replay' : 'Playing';
}

export function useRuntime<S>(selector: (s: RuntimeState) => S, equality?: (a: S, b: S) => boolean): S {
  return useStore(runtimeStore, selector, equality);
}

/* ------------------------------------------------------------------ */
/* Offline readiness (service worker)                                  */
/* ------------------------------------------------------------------ */

export type OfflineState = 'unsupported' | 'installing' | 'ready' | 'update-ready' | 'error';

/** `apply` installs a waiting new version (the page reloads); set only in 'update-ready'. */
export const offlineStore = createStore<{ state: OfflineState; apply: (() => void) | null }>({ state: 'unsupported', apply: null });

export function useOffline() {
  return useStore(offlineStore, (s) => s);
}
