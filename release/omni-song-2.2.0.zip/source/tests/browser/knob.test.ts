import { createElement as h } from 'react';
import { afterEach, describe, expect, it } from 'vitest';
import { Knob, TipsProvider, type KnobChangeInfo } from '../../src/ui/components';
import { BASS_PARAMS, CHANNEL_PARAMS, POLY_PARAMS, formatParam, fromNormalized, specById, toNormalized, type ParamSpec } from '../../src/project/params';
import { actFrame, cleanup, fire, key, mount, pointer, pointIn, wait } from './ui-harness';

const AMOUNT: ParamSpec = { id: 'amount', label: 'Amount', min: 0, max: 1, default: 0.25, unit: '%', curve: 'lin', tip: 'How much.' };
const CUTOFF = specById(BASS_PARAMS, 'cutoff')!;
const WAVE = specById(BASS_PARAMS, 'wave')!;
const OCTAVE = specById(BASS_PARAMS, 'octave')!;
const PAN = specById(CHANNEL_PARAMS, 'pan')!;

type Call = [number, KnobChangeInfo];

function setup(spec: ParamSpec, value: number, extra: Record<string, unknown> = {}) {
  const calls: Call[] = [];
  const m = mount(h(Knob, { spec, value, onChange: (v: number, info: KnobChangeInfo) => calls.push([v, info]), ...extra }));
  const slider = m.container.querySelector<HTMLElement>('[role="slider"]')!;
  return { m, calls, slider };
}

function drag(slider: HTMLElement, dy: number, init: PointerEventInit = {}) {
  const start = pointIn(slider);
  pointer(slider, 'pointerdown', start);
  // Several small moves, like a real drag.
  const steps = 5;
  for (let i = 1; i <= steps; i++) pointer(slider, 'pointermove', { ...start, clientY: start.clientY - (dy * i) / steps, ...init });
  pointer(slider, 'pointerup', { ...start, clientY: start.clientY - dy });
}

afterEach(cleanup);

describe('Knob dragging', () => {
  it('dragging up increases the value; 200 px covers the full range', () => {
    const { calls, slider } = setup(AMOUNT, 0.5);
    drag(slider, 50);
    const last = calls[calls.length - 1];
    expect(last[1].final).toBe(true);
    expect(last[0]).toBeCloseTo(0.75, 5);
    // One drag = one gesture id.
    expect(new Set(calls.map((c) => c[1].gesture)).size).toBe(1);
  });

  it('dragging down decreases and clamps at the minimum', () => {
    const { calls, slider } = setup(AMOUNT, 0.5);
    drag(slider, -400);
    expect(calls[calls.length - 1][0]).toBe(0);
  });

  it('Shift makes the drag 10x finer', () => {
    const { calls, slider } = setup(AMOUNT, 0.5);
    drag(slider, 50, { shiftKey: true });
    expect(calls[calls.length - 1][0]).toBeCloseTo(0.525, 5);
  });

  it('moves evenly in normalised space on exponential parameters', () => {
    const { calls, slider } = setup(CUTOFF, 700);
    drag(slider, 40); // 20% of travel
    const expected = fromNormalized(CUTOFF, toNormalized(CUTOFF, 700) + 0.2);
    expect(calls[calls.length - 1][0]).toBeCloseTo(expected, 3);
    // Geometric, not linear: +20% of travel from 700 Hz is far less than +20% of the Hz range.
    expect(expected).toBeLessThan(700 + 0.2 * (CUTOFF.max - CUTOFF.min));
  });

  it('coalesces changes to at most one per animation frame during a drag', async () => {
    const { calls, slider } = setup(AMOUNT, 0.5);
    const start = pointIn(slider);
    pointer(slider, 'pointerdown', start);
    for (let i = 1; i <= 8; i++) pointer(slider, 'pointermove', { ...start, clientY: start.clientY - i * 4 });
    expect(calls.length).toBe(0);
    await actFrame();
    expect(calls.length).toBe(1);
    expect(calls[0][1].final).toBe(false);
    expect(calls[0][0]).toBeCloseTo(0.5 + 32 / 200, 5);
    pointer(slider, 'pointerup', { ...start, clientY: start.clientY - 32 });
    expect(calls.length).toBe(2);
    expect(calls[1]).toEqual([calls[0][0], { gesture: calls[0][1].gesture, final: true }]);
  });

  it('a pointer cancel ends the gesture with a final call', () => {
    const { calls, slider } = setup(AMOUNT, 0.5);
    const start = pointIn(slider);
    pointer(slider, 'pointerdown', start);
    pointer(slider, 'pointermove', { ...start, clientY: start.clientY - 20 });
    pointer(slider, 'pointercancel', start);
    expect(calls.length).toBe(1);
    expect(calls[0][1].final).toBe(true);
    expect(calls[0][0]).toBeCloseTo(0.6, 5);
  });

  it('a click without movement changes nothing', () => {
    const { calls, slider } = setup(AMOUNT, 0.5);
    const p = pointIn(slider);
    pointer(slider, 'pointerdown', p);
    pointer(slider, 'pointerup', p);
    expect(calls).toEqual([]);
  });

  it('double-click resets to the default', () => {
    const { calls, slider } = setup(CUTOFF, 3000);
    fire(slider, new MouseEvent('dblclick', { bubbles: true, cancelable: true }));
    expect(calls).toHaveLength(1);
    expect(calls[0][0]).toBe(CUTOFF.default);
    expect(calls[0][1].final).toBe(true);
  });

  it('a knob controlled by a macro is read-only and names the macro', () => {
    const { calls, slider, m } = setup(CUTOFF, 3000, { controlledBy: 'Tone' });
    drag(slider, 60);
    key(slider, 'keydown', { key: 'ArrowUp' });
    fire(slider, new MouseEvent('dblclick', { bubbles: true }));
    expect(calls).toEqual([]);
    expect(slider.getAttribute('aria-readonly')).toBe('true');
    expect(slider.getAttribute('aria-valuetext')).toBe('3.00 kHz, set by Tone');
    expect(m.container.textContent).toContain('Tone');
  });

  it('a disabled knob ignores input and leaves the tab order', () => {
    const { calls, slider } = setup(AMOUNT, 0.5, { disabled: true });
    drag(slider, 60);
    key(slider, 'keydown', { key: 'ArrowUp' });
    expect(calls).toEqual([]);
    expect(slider.tabIndex).toBe(-1);
    expect(slider.getAttribute('aria-disabled')).toBe('true');
  });
});

describe('Knob keyboard', () => {
  it('arrow keys step 1% of travel, Shift 0.1%, PageUp 10%, Home/End jump to the ends', () => {
    const { calls, slider } = setup(AMOUNT, 0.5);
    slider.focus();
    key(slider, 'keydown', { key: 'ArrowUp' });
    expect(calls.at(-1)![0]).toBeCloseTo(0.51, 6);
    key(slider, 'keydown', { key: 'ArrowUp', shiftKey: true });
    expect(calls.at(-1)![0]).toBeCloseTo(0.511, 6);
    key(slider, 'keydown', { key: 'ArrowDown' });
    expect(calls.at(-1)![0]).toBeCloseTo(0.501, 6);
    key(slider, 'keydown', { key: 'PageUp' });
    expect(calls.at(-1)![0]).toBeCloseTo(0.601, 6);
    key(slider, 'keydown', { key: 'End' });
    expect(calls.at(-1)![0]).toBe(1);
    key(slider, 'keydown', { key: 'Home' });
    expect(calls.at(-1)![0]).toBe(0);
    // The whole burst is one gesture; leaving the knob finalises it.
    expect(new Set(calls.map((c) => c[1].gesture)).size).toBe(1);
    expect(calls.every((c) => !c[1].final)).toBe(true);
    slider.blur();
    expect(calls.at(-1)).toEqual([0, { gesture: calls[0][1].gesture, final: true }]);
  });

  it('a key burst finalises by itself after a pause', async () => {
    const { calls, slider } = setup(AMOUNT, 0.5);
    slider.focus();
    key(slider, 'keydown', { key: 'ArrowUp' });
    await wait(900);
    expect(calls.at(-1)![1].final).toBe(true);
    key(slider, 'keydown', { key: 'ArrowUp' });
    expect(calls.at(-1)![1].gesture).not.toBe(calls[0][1].gesture);
  });

  it('stepped parameters move by at least one step', () => {
    const { calls, slider } = setup(OCTAVE, 0);
    slider.focus();
    key(slider, 'keydown', { key: 'ArrowUp' });
    expect(calls.at(-1)![0]).toBe(1);
    key(slider, 'keydown', { key: 'ArrowUp', shiftKey: true });
    expect(calls.at(-1)![0]).toBe(2);
    key(slider, 'keydown', { key: 'ArrowUp' });
    expect(calls).toHaveLength(2); // already at the maximum: no change reported
  });

  it('Delete resets to the default (keyboard equivalent of double-click)', () => {
    const { calls, slider } = setup(AMOUNT, 0.9);
    slider.focus();
    key(slider, 'keydown', { key: 'Delete' });
    expect(calls.at(-1)![0]).toBe(0.25);
  });
});

describe('Knob wheel', () => {
  it('does nothing unless the knob has keyboard focus', () => {
    const { calls, slider } = setup(AMOUNT, 0.5);
    const unfocused = new WheelEvent('wheel', { deltaY: -100, bubbles: true, cancelable: true });
    fire(slider, unfocused);
    expect(calls).toEqual([]);
    expect(unfocused.defaultPrevented).toBe(false); // the page scrolls normally

    slider.focus();
    const focused = new WheelEvent('wheel', { deltaY: -100, bubbles: true, cancelable: true });
    fire(slider, focused);
    expect(focused.defaultPrevented).toBe(true);
    expect(calls).toHaveLength(1);
    expect(calls[0][0]).toBeGreaterThan(0.5);
  });

  it('does nothing after the knob was merely clicked (pointer focus is not keyboard focus)', () => {
    const { calls, slider } = setup(AMOUNT, 0.5);
    const p = pointIn(slider);
    pointer(slider, 'pointerdown', p);
    pointer(slider, 'pointerup', p);
    expect(document.activeElement).toBe(slider);
    const wheel = (deltaY: number) => fire(slider, new WheelEvent('wheel', { deltaY, bubbles: true, cancelable: true }));
    expect(wheel(-100).defaultPrevented).toBe(false);
    // Keys that are not "using this knob" keep it disarmed: Shift alone, Space (Play), a note letter.
    key(slider, 'keydown', { key: 'Shift', shiftKey: true });
    key(slider, 'keydown', { key: ' ', code: 'Space' });
    key(slider, 'keydown', { key: 'a', code: 'KeyA' });
    expect(wheel(-100).defaultPrevented).toBe(false);
    expect(calls).toEqual([]);
    // Turning it with the keyboard arms the wheel.
    key(slider, 'keydown', { key: 'ArrowUp' });
    expect(calls).toHaveLength(1);
    expect(wheel(100).defaultPrevented).toBe(true);
    expect(calls).toHaveLength(2);
    expect(calls[1][0]).toBeLessThan(calls[0][0]);
  });

  it('a right-click (which focuses natively) does not arm the wheel', () => {
    const { calls, slider } = setup(AMOUNT, 0.5);
    const p = pointIn(slider);
    pointer(slider, 'pointerdown', { ...p, button: 2, buttons: 2 });
    // The browser focuses the element during the same press.
    slider.focus();
    const ev = fire(slider, new WheelEvent('wheel', { deltaY: -100, bubbles: true, cancelable: true }));
    expect(ev.defaultPrevented).toBe(false);
    expect(calls).toEqual([]);
  });

  it('the wheel never changes a read-only (macro-controlled) knob, even with keyboard focus', () => {
    const { calls, slider } = setup(CUTOFF, 3000, { controlledBy: 'Tone' });
    slider.focus();
    const ev = fire(slider, new WheelEvent('wheel', { deltaY: -100, bubbles: true, cancelable: true }));
    expect(ev.defaultPrevented).toBe(false);
    expect(calls).toEqual([]);
  });
});

describe('Knob lifecycle', () => {
  it('unmounting mid-drag closes the gesture with a final call', () => {
    const { calls, slider, m } = setup(AMOUNT, 0.5);
    const start = pointIn(slider);
    pointer(slider, 'pointerdown', start);
    pointer(slider, 'pointermove', { ...start, clientY: start.clientY - 20 });
    m.unmount();
    expect(calls).toHaveLength(1);
    expect(calls[0][0]).toBeCloseTo(0.6, 5);
    expect(calls[0][1].final).toBe(true);
  });

  it('becoming macro-controlled mid-drag ends the gesture and ignores further moves', () => {
    const calls: Call[] = [];
    const onChange = (v: number, info: KnobChangeInfo) => calls.push([v, info]);
    const m = mount(h(Knob, { spec: AMOUNT, value: 0.5, onChange }));
    const slider = m.container.querySelector<HTMLElement>('[role="slider"]')!;
    const start = pointIn(slider);
    pointer(slider, 'pointerdown', start);
    pointer(slider, 'pointermove', { ...start, clientY: start.clientY - 20 });
    m.rerender(h(Knob, { spec: AMOUNT, value: 0.5, onChange, controlledBy: 'Drive' }));
    expect(calls.at(-1)![1].final).toBe(true);
    const n = calls.length;
    pointer(slider, 'pointermove', { ...start, clientY: start.clientY - 60 });
    pointer(slider, 'pointerup', { ...start, clientY: start.clientY - 60 });
    expect(calls).toHaveLength(n);
  });
});

describe('Knob accessibility', () => {
  it('exposes slider semantics with a unit-formatted value text', () => {
    const { slider } = setup(CUTOFF, 2400);
    expect(slider.getAttribute('role')).toBe('slider');
    expect(slider.getAttribute('aria-label')).toBe('Cutoff');
    expect(slider.getAttribute('aria-valuemin')).toBe(String(CUTOFF.min));
    expect(slider.getAttribute('aria-valuemax')).toBe(String(CUTOFF.max));
    expect(slider.getAttribute('aria-valuenow')).toBe('2400');
    expect(slider.getAttribute('aria-valuetext')).toBe(formatParam(CUTOFF, 2400));
    expect(slider.getAttribute('aria-valuetext')).toBe('2.40 kHz');
    expect(slider.tabIndex).toBe(0);
  });

  it('enum parameters read their option names', () => {
    const { slider, calls } = setup(WAVE, 1);
    expect(slider.getAttribute('aria-valuetext')).toBe('Square');
    slider.focus();
    key(slider, 'keydown', { key: 'ArrowUp' });
    expect(calls.at(-1)![0]).toBe(2);
    expect(slider.getAttribute('aria-valuetext')).toBe('Triangle');
  });

  it('a custom label becomes the accessible name; modulation is announced', () => {
    const { slider } = setup(PAN, -0.2, { label: 'Bass pan', modulated: true });
    expect(slider.getAttribute('aria-label')).toBe('Bass pan');
    expect(slider.getAttribute('aria-valuetext')).toBe('L20, modulated');
  });

  it('the tip is linked with aria-describedby', () => {
    const { slider } = setup(CUTOFF, 700);
    const id = slider.getAttribute('aria-describedby');
    expect(id).toBeTruthy();
    expect(document.getElementById(id!)!.textContent).toContain(CUTOFF.tip);
  });
});

describe('Knob numeric entry', () => {
  it('Enter opens an entry field; "2.5k" sets 2500 Hz', () => {
    const { calls, slider, m } = setup(CUTOFF, 700);
    slider.focus();
    key(slider, 'keydown', { key: 'Enter' });
    const input = m.container.querySelector('input')!;
    expect(input).toBeTruthy();
    expect(document.activeElement).toBe(input);
    setInput(input, '2.5k');
    key(input, 'keydown', { key: 'Enter' });
    expect(calls).toHaveLength(1);
    expect(calls[0][0]).toBe(2500);
    expect(calls[0][1].final).toBe(true);
    expect(m.container.querySelector('input')).toBeNull();
    expect(document.activeElement).toBe(slider);
  });

  it('typing a digit starts entry with that digit; units and signs are understood', () => {
    const level = specById(BASS_PARAMS, 'level')!;
    const { calls, slider, m } = setup(level, 0);
    slider.focus();
    const ev = key(slider, 'keydown', { key: '-' });
    expect(ev.defaultPrevented).toBe(true);
    const input = m.container.querySelector('input')!;
    expect(input.value).toBe('-');
    setInput(input, '-6 dB');
    key(input, 'keydown', { key: 'Enter' });
    expect(calls.at(-1)![0]).toBe(-6);
  });

  it('Escape cancels; invalid text keeps the field open and changes nothing', () => {
    const { calls, slider, m } = setup(CUTOFF, 700);
    slider.focus();
    key(slider, 'keydown', { key: 'Enter' });
    let input = m.container.querySelector('input')!;
    setInput(input, 'loud');
    key(input, 'keydown', { key: 'Enter' });
    input = m.container.querySelector('input')!;
    expect(input).toBeTruthy();
    expect(input.getAttribute('aria-invalid')).toBe('true');
    key(input, 'keydown', { key: 'Escape' });
    expect(m.container.querySelector('input')).toBeNull();
    expect(calls).toEqual([]);
  });

  it('times typed as plain numbers are read in the unit shown (ms below one second)', () => {
    const decay = specById(BASS_PARAMS, 'decay')!; // shows "300 ms"
    const { calls, slider, m } = setup(decay, 0.3);
    slider.focus();
    key(slider, 'keydown', { key: '4' });
    const input = m.container.querySelector('input')!;
    setInput(input, '450');
    key(input, 'keydown', { key: 'Enter' });
    expect(calls.at(-1)![0]).toBeCloseTo(0.45, 6);
  });

  it('a small number on a time shown in ms stays ms; a large one on a time shown in s becomes ms', () => {
    const attack = specById(POLY_PARAMS, 'attack')!; // 1 ms .. 4 s
    const typeInto = (value: number, text: string) => {
      const { calls, slider, m } = setup(attack, value);
      slider.focus();
      key(slider, 'keydown', { key: 'Enter' });
      const input = m.container.querySelector('input')!;
      setInput(input, text);
      key(input, 'keydown', { key: 'Enter' });
      m.unmount();
      return calls.at(-1)![0];
    };
    // The knob reads "5 ms": typing 2 means 2 ms, not a 2-second swell.
    expect(typeInto(0.005, '2')).toBeCloseTo(0.002, 6);
    // It reads "1.20 s": 2 means 2 s, and 500 (beyond the range in seconds) means 500 ms.
    expect(typeInto(1.2, '2')).toBeCloseTo(2, 6);
    expect(typeInto(1.2, '500')).toBeCloseTo(0.5, 6);
    // Explicit units always win.
    expect(typeInto(0.005, '1.5 s')).toBeCloseTo(1.5, 6);
    expect(typeInto(1.2, '80ms')).toBeCloseTo(0.08, 6);
  });
});

describe('Knob tips name the gestures', () => {
  const described = (el: Element) => document.getElementById(el.getAttribute('aria-describedby')!)?.textContent ?? '';

  it('say how to turn it, what double-click restores and how to type an exact value; each works as described', () => {
    const { calls, slider, m } = setup(CUTOFF, 3000);
    const home = formatParam(CUTOFF, CUTOFF.default); // "700 Hz"
    const text = described(slider);
    expect(text).toContain('Drag up or down, or use the arrow keys; hold Shift for fine steps.');
    expect(text).toContain(`Double-click resets it to ${home}.`);
    expect(text).toContain('For an exact value, click the value under it, or click the knob and type a number.');

    // A mouse user: click the knob, then type.
    const p = pointIn(slider);
    pointer(slider, 'pointerdown', p);
    pointer(slider, 'pointerup', p);
    key(document.activeElement!, 'keydown', { key: '2' });
    const input = m.container.querySelector('input')!;
    expect(input).toBeTruthy();
    setInput(input, '2.5k');
    key(input, 'keydown', { key: 'Enter' });
    expect(calls.at(-1)![0]).toBe(2500);

    // Double-click goes back to the value the tip names.
    fire(slider, new MouseEvent('dblclick', { bubbles: true, cancelable: true }));
    expect(formatParam(CUTOFF, calls.at(-1)![0])).toBe(home);
  });

  it('the hint comes after the technical detail in the visible tip', async () => {
    const { m, slider } = setup(CUTOFF, 3000);
    const other = document.createElement('button');
    m.container.prepend(other);
    other.focus();
    key(other, 'keydown', { key: 'Tab' }); // keyboard focus shows the tip at once
    slider.focus();
    await actFrame();
    const bubble = [...document.body.querySelectorAll<HTMLElement>('[aria-hidden="true"]')].find((el) => el.textContent?.includes('Drag up or down'));
    expect(bubble).toBeTruthy();
    const text = bubble!.textContent!;
    expect(text.indexOf(CUTOFF.tip!)).toBeLessThan(text.indexOf(CUTOFF.detail!));
    expect(text.indexOf(CUTOFF.detail!)).toBeLessThan(text.indexOf('Drag up or down'));
  });

  it('option knobs name the default option and do not offer number entry', () => {
    const { slider } = setup(WAVE, 2);
    const text = described(slider);
    expect(text).toContain(`Double-click resets it to ${formatParam(WAVE, WAVE.default)}.`);
    expect(text).not.toContain('type a number');
  });

  it('knobs that cannot be turned do not describe gestures they ignore', () => {
    const readOnly = setup(CUTOFF, 3000, { controlledBy: 'Tone' });
    expect(described(readOnly.slider)).toContain('Set by the Tone macro');
    expect(described(readOnly.slider)).not.toContain('Drag up or down');
    readOnly.m.unmount();
    const disabled = setup(AMOUNT, 0.5, { disabled: true });
    expect(described(disabled.slider)).not.toContain('Drag up or down');
  });

  it('with Tips off, only the name is given', () => {
    const m = mount(h(TipsProvider, { enabled: false }, h(Knob, { spec: CUTOFF, value: 3000, onChange: () => {} })));
    const slider = m.container.querySelector<HTMLElement>('[role="slider"]')!;
    expect(described(slider)).toContain('Cutoff');
    expect(described(slider)).not.toContain('Drag up or down');
  });
});

/** Set an input's value the way typing does, so React's onChange fires. */
function setInput(input: HTMLInputElement, value: string) {
  const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')!.set!;
  setter.call(input, value);
  fire(input, new Event('input', { bubbles: true }));
}
